package com.example.aikeyboard

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI

object AiClient {
    private const val MAX_TEXT = 12_000

    fun run(ctx: Context, mode: String, text: String, cb: (Result<String>) -> Unit) {
        Thread {
            cb(runCatching {
                require(mode in setOf("spell", "formal", "friendly", "translate", "reply", "suggest"))
                require(text.isNotBlank())
                val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                val base = (p.getString("server", "") ?: "").trim().trimEnd('/')
                require(base.startsWith("https://"))
                val c = URI("$base/ai").toURL().openConnection() as HttpURLConnection
                try {
                    c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 30000; c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    p.getString("token", "")?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("x-app-token", it) }
                    c.outputStream.use { it.write(JSONObject().put("mode", mode).put("text", text.take(MAX_TEXT)).toString().toByteArray(Charsets.UTF_8)) }
                    if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
                    JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getString("result")
                } finally { c.disconnect() }
            })
        }.start()
    }
}
