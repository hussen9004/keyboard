package com.example.aikeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlin.math.*

class StickerActivity : Activity() {
    private var original: Bitmap? = null
    private var cut: Bitmap? = null
    private var result: Bitmap? = null
    private var color = Color.WHITE
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var cutSwitch: Switch
    private lateinit var borderSwitch: Switch
    private lateinit var caption: EditText
    private lateinit var fontSpin: Spinner
    private lateinit var fonts: List<Pair<String, Typeface>>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fonts = mutableListOf(
            "عريض" to Typeface.DEFAULT_BOLD, "ناسخ" to Typeface.create(Typeface.SERIF, Typeface.BOLD), "عادي" to Typeface.SANS_SERIF
        ).also { l ->
            assets.list("fonts")?.filter { it.endsWith(".ttf") || it.endsWith(".otf") }?.forEach {
                runCatching { l.add(it.substringBeforeLast('.') to Typeface.createFromAsset(assets, "fonts/$it")) }
            }
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(16)) }
        box.addView(Button(this).apply { text = "📷 اختيار صورة من الاستديو"; setOnClickListener { pick() } })
        preview = ImageView(this).apply {
            setBackgroundColor(Color.parseColor("#334155"))
            layoutParams = LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(8); bottomMargin = dp(8) }
        }
        box.addView(preview)
        status = TextView(this).apply { text = "اختر صورة لتبدأ" }
        box.addView(status)
        cutSwitch = Switch(this).apply {
            text = "✂️ قص ذكي (إزالة الخلفية)"
            setOnCheckedChangeListener { _, on -> if (on && cut == null && original != null) runCut() else refresh() }
        }
        borderSwitch = Switch(this).apply {
            text = "⬜ إطار أبيض"; isChecked = true; setOnCheckedChangeListener { _, _ -> refresh() }
        }
        box.addView(cutSwitch); box.addView(borderSwitch)
        caption = EditText(this).apply { hint = "نص مزخرف (اختياري)"; doAfterTextChanged { refresh() } }
        box.addView(caption)
        fontSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@StickerActivity, android.R.layout.simple_spinner_dropdown_item, fonts.map { it.first })
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refresh()
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        box.addView(fontSpin)
        val colors = LinearLayout(this)
        listOf("#FFFFFF", "#FACC15", "#38BDF8", "#F472B6").forEach { hex ->
            colors.addView(View(this).apply {
                setBackgroundColor(Color.parseColor(hex))
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(6), dp(8), dp(6), dp(8)) }
                setOnClickListener { color = Color.parseColor(hex); refresh() }
            })
        }
        box.addView(colors)
        box.addView(Button(this).apply { text = "💾 حفظ في المكتبة"; setOnClickListener { save() } })
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != 1 || res != RESULT_OK) return
        original = runCatching { load(uri) }.getOrNull()
        cut = null
        if (original == null) { status.text = "⚠️ تعذر فتح الصورة"; return }
        status.text = "تم تحميل الصورة"
        if (!cutSwitch.isChecked) cutSwitch.isChecked = true else runCut()
    }

    private fun load(uri: Uri): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 1024) s *= 2
        val bmp = contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }!!
        val exif = contentResolver.openInputStream(uri)!!.use { ExifInterface(it) }
        val deg = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        return if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
    }

    private fun runCut() {
        val src = original ?: return
        status.text = "⏳ جاري عزل الخلفية بالذكاء الاصطناعي..."
        val seg = SubjectSegmentation.getClient(SubjectSegmenterOptions.Builder().enableForegroundBitmap().build())
        seg.process(InputImage.fromBitmap(src, 0))
            .addOnSuccessListener { r ->
                cut = r.foregroundBitmap
                status.text = if (cut != null) "تم عزل الخلفية ✓" else "لم يُعثر على عنصر واضح"
                if (cut == null) cutSwitch.isChecked = false else refresh()
            }
            .addOnFailureListener {
                status.text = "⚠️ تعذر القص: يحتاج خدمات Google Play واتصالاً بالإنترنت أول مرة"
                cutSwitch.isChecked = false
            }
    }

    private fun withBorder(src: Bitmap): Bitmap {
        val r = max(4, src.width / 70); val pad = r * 2
        val out = Bitmap.createBitmap(src.width + pad * 2, src.height + pad * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN) }
        for (i in 0 until 32) {
            val a = 2 * PI * i / 32
            c.drawBitmap(src, (pad + r * cos(a)).toFloat(), (pad + r * sin(a)).toFloat(), p)
        }
        c.drawBitmap(src, pad.toFloat(), pad.toFloat(), null)
        return out
    }

    private fun refresh() {
        val base = (if (cutSwitch.isChecked) cut else null) ?: original ?: return
        val b = if (borderSwitch.isChecked) withBorder(base) else base
        val out = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = min(512f / b.width, 512f / b.height) * 0.96f
        val w = b.width * s; val h = b.height * s
        c.drawBitmap(b, null, RectF((512 - w) / 2, (512 - h) / 2, (512 + w) / 2, (512 + h) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        val t = caption.text.toString().trim()
        if (t.isNotEmpty()) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = fonts[fontSpin.selectedItemPosition].second; textAlign = Paint.Align.CENTER; textSize = 72f
            }
            while (p.measureText(t) > 470 && p.textSize > 16f) p.textSize -= 2f
            p.style = Paint.Style.STROKE; p.strokeWidth = p.textSize / 5; p.color = Color.BLACK; p.strokeJoin = Paint.Join.ROUND
            c.drawText(t, 256f, 490f, p)
            p.style = Paint.Style.FILL; p.color = color
            c.drawText(t, 256f, 490f, p)
        }
        result = out
        preview.setImageBitmap(out)
    }

    private fun save() {
        val r = result ?: run { status.text = "اختر صورة أولاً"; return }
        StickerStore.save(this, r)
        status.text = "✓ حُفظ. افتح الكيبورد في أي محادثة واضغط «🖼 ملصقات»"
    }
}
