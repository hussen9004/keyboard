# نشر وسيط OpenAI مجانًا

## قبل النشر

ارفع مجلد `server/` إلى مستودع GitHub مستقل أو إلى مستودع المشروع. يجب أن يحتوي على `server.js` و`package.json` فقط على الأقل. لا ترفع ملف `.env` أو أي مفتاح يبدأ بـ `sk-`.

الخادم يستمع على `process.env.PORT`، ويستخدم `0.0.0.0`، لذلك يتوافق مع Render وRailway. فحص الصحة هو `GET /health`.

## Render

1. ادخل إلى [Render](https://render.com) واختر **New > Web Service**.
2. اربط مستودع GitHub، ثم اجعل **Root Directory** هو `server` إذا كان الخادم داخل مجلد `server/`.
3. اختر:
   - Runtime: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: `Free`
4. من **Environment** أضف:
   - `OPENAI_API_KEY`: مفتاح OpenAI.
   - `OPENAI_MODEL`: `gpt-4o-mini`.
   - `APP_TOKEN`: رمز عشوائي طويل.
   - `PORT`: اترك Render يحدده تلقائيًا، أو لا تضف هذا المتغير.
5. أنشئ الخدمة وانتظر اكتمال النشر. سيظهر عنوان مثل `https://اسم-الخدمة.onrender.com`.
6. اختبر `https://اسم-الخدمة.onrender.com/health` ويجب أن يعيد `ok`.
7. أدخل العنوان في تطبيق الكيبورد مع حذف `/health`، أي استخدم `https://اسم-الخدمة.onrender.com`، ثم أدخل نفس `APP_TOKEN`.

Render يوفر TLS مُدارًا للخدمات المجانية، لكن الخدمة المجانية تدخل السكون بعد 15 دقيقة بلا طلبات وتحتاج عادةً وقتًا للاستيقاظ عند أول طلب. لا تعتمد عليها لخدمة إنتاج حرجة.

## Railway

1. ادخل إلى [Railway](https://railway.com) واختر **New Project > Deploy from GitHub repo**.
2. اختر المستودع. إذا كان الخادم داخل `server/`، اضبط **Root Directory** أو أنشئ مستودعًا يحتوي على الخادم فقط.
3. أضف المتغيرات من تبويب **Variables**:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL=gpt-4o-mini`
   - `APP_TOKEN`
4. انشر الخدمة. من **Settings > Networking > Public Networking** اضغط **Generate Domain**.
5. استخدم النطاق الذي ينتهي بـ `.up.railway.app` عبر HTTPS، واختبر `/health`.
6. أدخل النطاق الأساسي، دون `/health`، ورمز `APP_TOKEN` في تطبيق الكيبورد.

الخطة المجانية في Railway تعطي رصيد استخدام شهريًا محدودًا، والخدمة تنام عند عدم وجود نشاط خارجي ثم تستيقظ عند الطلب. راقب الاستخدام حتى لا تتوقف الخدمة عند نفاد الرصيد.

## اختبار الطلب

```bash
curl -X POST https://YOUR_DOMAIN/ai \
  -H 'Content-Type: application/json' \
  -H 'x-app-token: YOUR_APP_TOKEN' \
  -d '{"mode":"formal","text":"هذا نص تجريبي"}'
```

النتيجة المتوقعة:

```json
{"result":"..."}
```

## مصادر رسمية

- [Render: نشر Node Express](https://render.com/docs/deploy-node-express-app)
- [Render: الموارد المجانية](https://render.com/docs/free)
- [Render: متغيرات البيئة والأسرار](https://render.com/docs/configure-environment-variables)
- [Railway: البدء السريع](https://docs.railway.com/quick-start)
- [Railway: الشبكة العامة وSSL](https://docs.railway.com/networking/public-networking)
- [Railway: الخطة المجانية](https://docs.railway.com/pricing/free-plan)
