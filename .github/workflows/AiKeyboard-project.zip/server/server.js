import http from 'node:http';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const APP_TOKEN = process.env.APP_TOKEN || '';
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const PORT = Number(process.env.PORT || 8787);
const MAX_TEXT = 12_000;

if (!OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is required');
if (!APP_TOKEN) console.warn('APP_TOKEN is not set; the /ai endpoint is public');

const PROMPTS = {
  spell: 'صحّح الإملاء والنحو في النص مع الحفاظ على المعنى واللهجة. أعد النص الناتج فقط دون شرح.',
  formal: 'أعد صياغة النص بأسلوب رسمي ومهذب وبنفس اللغة. أعد النص الناتج فقط دون شرح.',
  friendly: 'أعد صياغة النص بأسلوب ودي ودافئ وبنفس اللغة، ويمكن إضافة إيموجي مناسب. أعد النص فقط دون شرح.',
  translate: 'إذا كان النص عربيًا ترجمه إلى الإنجليزية، وإذا كان بغير العربية ترجمه إلى العربية. أعد الترجمة فقط.',
  reply: 'اكتب ردًا قصيرًا ومناسبًا بنفس لغة ولهجة الرسالة. أعد الرد فقط دون شرح.',
  suggest: 'اقترح 3 تكملات قصيرة ومناسبة للنص العربي الحالي. اكتب كل اقتراح في سطر مستقل، دون أرقام أو شرح، وبحد أقصى 6 كلمات لكل اقتراح.'
};

function send(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
  });
  res.end(JSON.stringify(body));
}

async function readBody(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body, 'utf8') > 20_000) throw new Error('PAYLOAD_TOO_LARGE');
  }
  return JSON.parse(body);
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
    return res.end('ok');
  }
  if (req.method !== 'POST' || req.url !== '/ai') return send(res, 404, { error: 'not_found' });
  if (APP_TOKEN && req.headers['x-app-token'] !== APP_TOKEN) return send(res, 401, { error: 'unauthorized' });

  try {
    const { mode, text } = await readBody(req);
    if (!PROMPTS[mode] || typeof text !== 'string' || !text.trim() || text.length > MAX_TEXT) {
      return send(res, 400, { error: 'invalid_request' });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 35_000);
    let response;
    try {
      response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: MODEL,
          temperature: 0.3,
          max_tokens: 600,
          messages: [
            { role: 'system', content: PROMPTS[mode] },
            { role: 'user', content: text.slice(0, MAX_TEXT) }
          ]
        })
      });
    } finally {
      clearTimeout(timeout);
    }

    const data = await response.json();
    if (!response.ok) {
      console.error('OpenAI request failed with status', response.status);
      return send(res, 502, { error: 'upstream_error' });
    }
    const result = data.choices?.[0]?.message?.content?.trim();
    if (!result) return send(res, 502, { error: 'empty_result' });
    return send(res, 200, { result });
  } catch (error) {
    if (error.message === 'PAYLOAD_TOO_LARGE') return send(res, 413, { error: 'payload_too_large' });
    console.error('Proxy request failed:', error.name === 'AbortError' ? 'timeout' : error.message);
    return send(res, 500, { error: 'server_error' });
  }
});

server.listen(PORT, '0.0.0.0', () => console.log(`OpenAI proxy listening on ${PORT}`));
